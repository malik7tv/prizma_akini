import zipfile
from pathlib import Path

root = Path("/home/user")
src = root / "src"

template = (src / "template.html").read_text(encoding="utf-8")
css = (src / "style.css").read_text(encoding="utf-8")

js_parts = [
    (src / "audio.js").read_text(encoding="utf-8"),
    (src / "grid.js").read_text(encoding="utf-8"),
    (src / "upgrades.js").read_text(encoding="utf-8"),
    (src / "game.js").read_text(encoding="utf-8"),
]
combined_js = "\n\n".join(js_parts)

out_html = template.replace("/* __INLINE_CSS__ */", css).replace("/* __INLINE_JS__ */", combined_js)
(root / "index.html").write_text(out_html, encoding="utf-8")
(root / "Prizma_Akini.html").write_text(out_html, encoding="utf-8")

zip_path = root / "Prizma_Akini.zip"
with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    zf.write(root / "Prizma_Akini.html", "Prizma_Akini/Prizma_Akini.html")
    zf.write(root / "BENI_OKU.md", "Prizma_Akini/BENI_OKU.md")
    zf.write(root / "build.py", "Prizma_Akini/build.py")
    for p in sorted(src.iterdir()):
        if p.is_file():
            zf.write(p, f"Prizma_Akini/src/{p.name}")

print(f"Hazir: index.html, Prizma_Akini.html ve Prizma_Akini.zip ({zip_path.stat().st_size:,} bayt)")
