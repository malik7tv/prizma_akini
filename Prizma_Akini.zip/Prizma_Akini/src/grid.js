// Etkileşimli Uzay-Zaman Elastik Yay Ağı (Warping Spring Grid)
class SpringGrid {
  constructor(worldW, worldH, spacing = 70) {
    this.spacing = spacing;
    this.cols = Math.floor(worldW / spacing) + 1;
    this.rows = Math.floor(worldH / spacing) + 1;
    this.points = [];

    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const ox = c * spacing;
        const oy = r * spacing;
        // Kenar noktalar sabit (anchor), iç noktalar hareketli
        const pinned = (r === 0 || c === 0 || r === this.rows - 1 || c === this.cols - 1);
        this.points.push({
          ox, oy,
          x: ox, y: oy,
          vx: 0, vy: 0,
          pinned
        });
      }
    }
  }

  // Patlama (push > 0) veya Karadelik çekimi (push < 0)
  applyForce(fx, fy, strength, radius) {
    const rSq = radius * radius;
    const minC = Math.max(1, Math.floor((fx - radius) / this.spacing));
    const maxC = Math.min(this.cols - 2, Math.ceil((fx + radius) / this.spacing));
    const minR = Math.max(1, Math.floor((fy - radius) / this.spacing));
    const maxR = Math.min(this.rows - 2, Math.ceil((fy + radius) / this.spacing));

    for (let r = minR; r <= maxR; r++) {
      for (let c = minC; c <= maxC; c++) {
        const p = this.points[r * this.cols + c];
        const dx = p.x - fx;
        const dy = p.y - fy;
        const dSq = dx * dx + dy * dy;
        if (dSq < rSq && dSq > 0.01) {
          const d = Math.sqrt(dSq);
          const falloff = 1 - d / radius;
          const f = (strength * falloff * falloff) / d;
          p.vx += dx * f;
          p.vy += dy * f;
        }
      }
    }
  }

  update(dt) {
    const stiffness = 26.0;
    const damping = 0.89;
    const step = Math.min(dt, 0.033);

    for (let i = 0; i < this.points.length; i++) {
      const p = this.points[i];
      if (p.pinned) continue;

      // Orijinal konuma geri çağıran yay kuvveti
      const ax = (p.ox - p.x) * stiffness;
      const ay = (p.oy - p.y) * stiffness;

      p.vx = (p.vx + ax * step) * damping;
      p.vy = (p.vy + ay * step) * damping;

      p.x += p.vx * step * 60 * 0.025;
      p.y += p.vy * step * 60 * 0.025;
    }
  }

  draw(ctx, camX, camY, viewW, viewH, hueShift = 0) {
    const margin = this.spacing * 2;
    const minC = Math.max(0, Math.floor((camX - margin) / this.spacing));
    const maxC = Math.min(this.cols - 1, Math.ceil((camX + viewW + margin) / this.spacing));
    const minR = Math.max(0, Math.floor((camY - margin) / this.spacing));
    const maxR = Math.min(this.rows - 1, Math.ceil((camY + viewH + margin) / this.spacing));

    // Önce sakin taban ızgarasını tek seferde çiz (yüksek performans)
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(28, 52, 105, 0.34)';
    ctx.beginPath();
    for (let r = minR; r <= maxR; r++) {
      for (let c = minC; c <= maxC; c++) {
        const p = this.points[r * this.cols + c];
        if (c < maxC) {
          const right = this.points[r * this.cols + c + 1];
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(right.x, right.y);
        }
        if (r < maxR) {
          const down = this.points[(r + 1) * this.cols + c];
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(down.x, down.y);
        }
      }
    }
    ctx.stroke();

    // Bükülen / enerji yüklü segmentleri parlak neon ile vurgula
    ctx.lineWidth = 1.6;
    for (let r = minR; r <= maxR; r++) {
      for (let c = minC; c <= maxC; c++) {
        const p = this.points[r * this.cols + c];
        const disp = Math.abs(p.x - p.ox) + Math.abs(p.y - p.oy);
        if (disp > 3.5) {
          const alpha = Math.min(0.85, (disp - 3.5) / 26);
          const hue = (190 + disp * 2.2 + hueShift) % 360;
          ctx.strokeStyle = `hsla(${hue}, 100%, 62%, ${alpha})`;
          ctx.beginPath();
          if (c < maxC) {
            const right = this.points[r * this.cols + c + 1];
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(right.x, right.y);
          }
          if (r < maxR) {
            const down = this.points[(r + 1) * this.cols + c];
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(down.x, down.y);
          }
          ctx.stroke();
        }
      }
    }
  }
}
