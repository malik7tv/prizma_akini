// PRİZMA AKINI (PRISM OVERDRIVE) - Ana Oyun Motoru

// Sandboxed iframe uyumlu güvenli depolama
const SafeStorage = {
  mem: {},
  get(key, fallback = null) {
    try {
      const val = window.localStorage.getItem(key);
      return val !== null ? JSON.parse(val) : (this.mem[key] ?? fallback);
    } catch (_) {
      return this.mem[key] ?? fallback;
    }
  },
  set(key, val) {
    this.mem[key] = val;
    try {
      window.localStorage.setItem(key, JSON.stringify(val));
    } catch (_) {}
  }
};

const WORLD_W = 2100;
const WORLD_H = 1470;

const DIFFICULTY_PRESETS = {
  chill: { hpMult: 0.78, dmgMult: 0.72, spawnMult: 0.82, scoreMult: 0.85, label: 'RAHAT' },
  normal: { hpMult: 1.0, dmgMult: 1.0, spawnMult: 1.0, scoreMult: 1.0, label: 'NORMAL' },
  chaos: { hpMult: 1.32, dmgMult: 1.35, spawnMult: 1.32, scoreMult: 1.5, label: 'KAOS' }
};

class Game {
  constructor() {
    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas.getContext('2d');
    this.sound = new SoundSystem();
    this.grid = new SpringGrid(WORLD_W, WORLD_H, 70);

    this.state = 'MENU'; // MENU, PLAYING, UPGRADE, PAUSED, GAMEOVER
    this.difficulty = 'normal';
    this.autoFire = true;

    this.viewW = window.innerWidth;
    this.viewH = window.innerHeight;
    this.dpr = 1;

    // Kamera & Ekran Efektleri
    this.cam = { x: WORLD_W / 2, y: WORLD_H / 2, shake: 0 };
    this.timeScale = 1.0;
    this.bulletTimeTimer = 0;
    this.hitStop = 0;
    this.hueShift = 0;
    this.damageFlash = 0;
    this.shieldFlash = 0;

    // İstatistikler
    this.highScore = SafeStorage.get('prism_highscore', 0);
    this.bestWave = SafeStorage.get('prism_bestwave', 0);
    this.totalKillsAllTime = SafeStorage.get('prism_totalkills', 0);

    // Girdi Durumu
    this.keys = {};
    this.mouse = { x: this.viewW / 2, y: this.viewH / 2, worldX: WORLD_W / 2, worldY: WORLD_H / 2, down: false };
    this.touch = {
      isTouch: false,
      moveId: null, moveStartX: 0, moveStartY: 0, dx: 0, dy: 0,
      aimId: null, aimStartX: 0, aimStartY: 0, ax: 0, ay: 0
    };

    // Paralaks Yıldız Katmanları
    this.stars = Array.from({ length: 160 }, () => ({
      x: Math.random() * WORLD_W,
      y: Math.random() * WORLD_H,
      size: Math.random() * 1.9 + 0.5,
      depth: Math.random() * 0.55 + 0.15,
      alpha: Math.random() * 0.65 + 0.2,
      hue: Math.random() > 0.7 ? 190 : (Math.random() > 0.5 ? 325 : 230)
    }));

    this.currentChoices = [];

    this.resize();
    this.bindEvents();
    this.initEntities();
    this.updateMenuStats();

    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  resize() {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.viewW = window.innerWidth;
    this.viewH = window.innerHeight;
    this.canvas.width = Math.floor(this.viewW * this.dpr);
    this.canvas.height = Math.floor(this.viewH * this.dpr);
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  initEntities() {
    this.score = 0;
    this.kills = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.wave = 1;
    this.waveTimer = 0;
    this.spawnTimer = 0.5;
    this.bossActive = false;

    this.player = {
      x: WORLD_W / 2,
      y: WORLD_H / 2,
      vx: 0,
      vy: 0,
      angle: 0,
      radius: 16,
      hp: 100,
      maxHp: 100,
      shield: 1,
      maxShield: 1,
      shieldRegenTimer: 0,
      speed: 390,
      damage: 24,
      fireRate: 0.17,
      fireCooldown: 0,
      bulletSpeed: 780,
      bulletSize: 5.2,
      projectiles: 1,
      pierce: 0,
      bounce: 0,
      chainLightning: 0,
      orbitals: 0,
      orbitalAngle: 0,
      homingLevel: 0,
      shotCount: 0,
      vortexDash: 0,
      critChance: 0.08,
      magnetRadius: 155,
      xp: 0,
      xpNext: 45,
      level: 1,
      nova: 50,
      novaChargeRate: 1.0,
      dashCooldown: 1.35,
      dashTimer: 0,
      dashActive: 0,
      invuln: 0,
      upgrades: {},
      trail: []
    };

    this.bullets = [];
    this.enemyBullets = [];
    this.missiles = [];
    this.enemies = [];
    this.gems = [];
    this.vortices = [];
    this.particles = [];
    this.shockwaves = [];
    this.lightnings = [];
    this.texts = [];
    this.afterimages = [];
  }

  bindEvents() {
    window.addEventListener('resize', () => this.resize());

    window.addEventListener('keydown', (e) => {
      const code = e.code;
      this.keys[code] = true;

      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(code)) {
        e.preventDefault();
      }

      if (this.state === 'UPGRADE') {
        if (code === 'Digit1' && this.currentChoices[0]) this.selectUpgrade(0);
        if (code === 'Digit2' && this.currentChoices[1]) this.selectUpgrade(1);
        if (code === 'Digit3' && this.currentChoices[2]) this.selectUpgrade(2);
        return;
      }

      if (code === 'KeyF') this.toggleAutoFire();
      if (code === 'KeyM') this.toggleSound();

      if (code === 'Escape' || code === 'KeyP') {
        if (this.state === 'PLAYING') this.setPause(true);
        else if (this.state === 'PAUSED') this.setPause(false);
      }

      if (this.state === 'PLAYING') {
        if (code === 'Space' || code === 'ShiftLeft' || code === 'ShiftRight') {
          this.triggerDash();
        }
        if (code === 'KeyQ' || code === 'KeyE') {
          this.triggerSupernova();
        }
      } else if (this.state === 'GAMEOVER' && code === 'KeyR') {
        this.startGame();
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });

    this.canvas.addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
    });

    this.canvas.addEventListener('mousedown', (e) => {
      this.sound.init();
      if (e.button === 0) {
        this.mouse.down = true;
      } else if (e.button === 2 && this.state === 'PLAYING') {
        this.triggerDash();
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.mouse.down = false;
    });

    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    // Dokunmatik Kontroller (Mobil & Tablet uyumu)
    this.canvas.addEventListener('touchstart', (e) => {
      this.sound.init();
      this.touch.isTouch = true;
      if (this.state === 'PLAYING') {
        document.getElementById('touchActions').classList.add('visible');
      }
      for (const t of e.changedTouches) {
        if (t.clientX < this.viewW * 0.5 && this.touch.moveId === null) {
          this.touch.moveId = t.identifier;
          this.touch.moveStartX = t.clientX;
          this.touch.moveStartY = t.clientY;
          this.touch.dx = 0;
          this.touch.dy = 0;
        } else if (this.touch.aimId === null) {
          this.touch.aimId = t.identifier;
          this.touch.aimStartX = t.clientX;
          this.touch.aimStartY = t.clientY;
        }
      }
    }, { passive: false });

    this.canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      for (const t of e.changedTouches) {
        if (t.identifier === this.touch.moveId) {
          const dx = t.clientX - this.touch.moveStartX;
          const dy = t.clientY - this.touch.moveStartY;
          const dist = Math.hypot(dx, dy) || 1;
          const maxR = 55;
          const clamped = Math.min(dist, maxR) / maxR;
          this.touch.dx = (dx / dist) * clamped;
          this.touch.dy = (dy / dist) * clamped;
        } else if (t.identifier === this.touch.aimId) {
          const dx = t.clientX - this.touch.aimStartX;
          const dy = t.clientY - this.touch.aimStartY;
          if (Math.hypot(dx, dy) > 8) {
            this.touch.ax = dx;
            this.touch.ay = dy;
          }
        }
      }
    }, { passive: false });

    const endTouch = (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier === this.touch.moveId) {
          this.touch.moveId = null;
          this.touch.dx = 0;
          this.touch.dy = 0;
        }
        if (t.identifier === this.touch.aimId) {
          this.touch.aimId = null;
        }
      }
    };
    this.canvas.addEventListener('touchend', endTouch);
    this.canvas.addEventListener('touchcancel', endTouch);

    // UI Butonları
    document.querySelectorAll('.diff-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.diff-btn').forEach((b) => b.classList.remove('selected'));
        btn.classList.add('selected');
        this.difficulty = btn.dataset.diff;
        this.sound.init();
        this.sound.playPickup(4);
      });
    });

    document.getElementById('startBtn').addEventListener('click', () => this.startGame());
    const dlBtn = document.getElementById('downloadHtmlBtn');
    if (dlBtn) {
      dlBtn.addEventListener('click', () => {
        const htmlContent = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
        const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Prizma_Akini.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      });
    }
    document.getElementById('restartBtn').addEventListener('click', () => this.startGame());
    document.getElementById('resumeBtn').addEventListener('click', () => this.setPause(false));
    document.getElementById('quitMenuBtn').addEventListener('click', () => this.backToMenu());

    document.getElementById('autoFireBtn').addEventListener('click', () => this.toggleAutoFire());
    document.getElementById('soundBtn').addEventListener('click', () => this.toggleSound());
    document.getElementById('pauseBtn').addEventListener('click', () => {
      if (this.state === 'PLAYING') this.setPause(true);
      else if (this.state === 'PAUSED') this.setPause(false);
    });

    document.getElementById('touchDashBtn').addEventListener('touchstart', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.triggerDash();
    });
    document.getElementById('touchNovaBtn').addEventListener('touchstart', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.triggerSupernova();
    });
  }

  toggleAutoFire() {
    this.autoFire = !this.autoFire;
    const btn = document.getElementById('autoFireBtn');
    btn.textContent = `OTO-ATEŞ: ${this.autoFire ? 'AÇIK' : 'KAPALI'} [F]`;
    btn.classList.toggle('active', this.autoFire);
  }

  toggleSound() {
    this.sound.init();
    const on = this.sound.toggleMute();
    const btn = document.getElementById('soundBtn');
    btn.textContent = on ? '🔊 SES [M]' : '🔇 SESSİZ [M]';
    btn.classList.toggle('active', on);
  }

  setPause(paused) {
    this.state = paused ? 'PAUSED' : 'PLAYING';
    document.getElementById('pauseOverlay').classList.toggle('hidden', !paused);
  }

  backToMenu() {
    this.state = 'MENU';
    document.getElementById('pauseOverlay').classList.add('hidden');
    document.getElementById('gameOverOverlay').classList.add('hidden');
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('touchActions').classList.remove('visible');
    document.getElementById('menuOverlay').classList.remove('hidden');
    this.updateMenuStats();
  }

  updateMenuStats() {
    document.getElementById('menuHighScore').textContent = this.highScore.toLocaleString('tr-TR');
    document.getElementById('menuBestWave').textContent = this.bestWave;
    document.getElementById('menuTotalKills').textContent = this.totalKillsAllTime.toLocaleString('tr-TR');
  }

  startGame() {
    this.sound.init();
    this.initEntities();
    this.grid = new SpringGrid(WORLD_W, WORLD_H, 70);
    this.state = 'PLAYING';

    document.getElementById('menuOverlay').classList.add('hidden');
    document.getElementById('gameOverOverlay').classList.add('hidden');
    document.getElementById('upgradeOverlay').classList.add('hidden');
    document.getElementById('pauseOverlay').classList.add('hidden');
    document.getElementById('hud').classList.remove('hidden');
    if (this.touch.isTouch) {
      document.getElementById('touchActions').classList.add('visible');
    }

    this.announceBanner('DALGA 1', 'SİSTEMLER AKTİF • HAYATTA KAL!');
    this.grid.applyForce(this.player.x, this.player.y, 130, 340);
    this.spawnShockwave(this.player.x, this.player.y, 260, '#00f0ff', 3);
    this.sound.playNova();
    this.spawnWaveBurst(6);
  }

  announceBanner(title, sub = '') {
    const el = document.getElementById('bannerMsg');
    document.getElementById('bannerTitle').textContent = title;
    document.getElementById('bannerSub').textContent = sub;
    el.classList.add('show');
    clearTimeout(this.bannerTimeout);
    this.bannerTimeout = setTimeout(() => el.classList.remove('show'), 2300);
  }

  // ==================== OYUN MEKANİKLERİ ====================

  triggerDash() {
    const p = this.player;
    if (p.dashTimer > 0 || p.dashActive > 0) return;

    p.dashTimer = p.dashCooldown;
    p.dashActive = 0.20;
    p.invuln = Math.max(p.invuln, 0.30);

    // Hareket yönü yoksa baktığı yöne atıl
    let dx = 0, dy = 0;
    if (this.keys['KeyW'] || this.keys['ArrowUp']) dy -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) dy += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) dx -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) dx += 1;
    if (this.touch.moveId !== null) { dx = this.touch.dx; dy = this.touch.dy; }

    let dashAngle = p.angle;
    if (dx !== 0 || dy !== 0) {
      dashAngle = Math.atan2(dy, dx);
    }

    const dashSpeed = 1280;
    p.vx = Math.cos(dashAngle) * dashSpeed;
    p.vy = Math.sin(dashAngle) * dashSpeed;

    this.sound.playDash();
    this.grid.applyForce(p.x, p.y, 120, 230);
    this.spawnShockwave(p.x, p.y, 120, '#00f0ff', 2.5);
    this.spawnParticles(p.x, p.y, 18, '#00f0ff', 320);

    // Tekillik Atılımı (Vortex Dash Yükseltmesi)
    if (p.vortexDash > 0) {
      this.vortices.push({
        x: p.x,
        y: p.y,
        life: 2.2 + p.vortexDash * 0.45,
        radius: 165 + p.vortexDash * 35,
        dps: p.damage * (1.8 + p.vortexDash * 0.7),
        tick: 0
      });
    }

    // Kusursuz Kaçış (Bullet-Time) Kontrolü: Yakında düşman mermisi veya düşman varsa!
    let nearThreat = false;
    for (const eb of this.enemyBullets) {
      if (Math.hypot(eb.x - p.x, eb.y - p.y) < 95) { nearThreat = true; break; }
    }
    if (!nearThreat) {
      for (const en of this.enemies) {
        if (Math.hypot(en.x - p.x, en.y - p.y) < en.radius + 58) { nearThreat = true; break; }
      }
    }

    if (nearThreat && this.bulletTimeTimer <= 0) {
      this.bulletTimeTimer = 1.65;
      p.nova = Math.min(100, p.nova + 18 * p.novaChargeRate);
      this.addScore(250);
      this.spawnText(p.x, p.y - 30, '⚡ KUSURSUZ KAÇIŞ! +250', '#00f0ff', 16);
      this.spawnShockwave(p.x, p.y, 320, '#ffd166', 3);
      this.sound.playPickup(8);
    }
  }

  triggerSupernova() {
    const p = this.player;
    if (p.nova < 100) return;

    p.nova = 0;
    p.invuln = 1.0;
    this.cam.shake = 26;
    this.hitStop = 0.05;
    this.sound.playNova();

    this.grid.applyForce(p.x, p.y, 340, 680);
    this.spawnShockwave(p.x, p.y, 720, '#ffd166', 6);
    this.spawnShockwave(p.x, p.y, 520, '#ff2a85', 4);
    this.spawnParticles(p.x, p.y, 65, '#ffd166', 620);

    // Tüm düşman mermilerini Prizma Kristallerine dönüştür!
    for (const eb of this.enemyBullets) {
      this.gems.push({ x: eb.x, y: eb.y, vx: 0, vy: 0, val: 4, hue: 50 });
      this.spawnParticles(eb.x, eb.y, 4, '#00f0ff', 140);
    }
    this.enemyBullets = [];

    // Menzildeki tüm düşmanlara ağır Süpernova hasarı
    const novaDmg = 95 + p.damage * 3.2;
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const en = this.enemies[i];
      const d = Math.hypot(en.x - p.x, en.y - p.y);
      if (d < 760) {
        const pushAngle = Math.atan2(en.y - p.y, en.x - p.x);
        en.vx += Math.cos(pushAngle) * 520;
        en.vy += Math.sin(pushAngle) * 520;
        this.damageEnemy(en, en.isBoss ? novaDmg * 0.45 : novaDmg, true);
      }
    }

    this.spawnText(p.x, p.y - 44, '☀️ PRİZMA SÜPERNOVASI!', '#ffd166', 20);
  }

  fireWeapon() {
    const p = this.player;
    p.fireCooldown = p.fireRate;
    p.shotCount++;

    const count = p.projectiles;
    const spreadTotal = Math.min(0.55, (count - 1) * 0.11);
    const isCrit = Math.random() < p.critChance;

    for (let i = 0; i < count; i++) {
      const offset = count === 1 ? 0 : -spreadTotal / 2 + (spreadTotal / (count - 1)) * i;
      const ang = p.angle + offset + (Math.random() - 0.5) * 0.025;
      const muzzleX = p.x + Math.cos(ang) * 20;
      const muzzleY = p.y + Math.sin(ang) * 20;

      this.bullets.push({
        x: muzzleX,
        y: muzzleY,
        vx: Math.cos(ang) * p.bulletSpeed,
        vy: Math.sin(ang) * p.bulletSpeed,
        radius: p.bulletSize * (isCrit ? 1.35 : 1),
        dmg: p.damage * (isCrit ? 2.3 : 1),
        isCrit,
        pierce: p.pierce,
        bounce: p.bounce,
        hitIds: new Set(),
        life: 2.1,
        trail: []
      });
    }

    // Güdümlü Mikro-Füzeler
    if (p.homingLevel > 0 && p.shotCount % Math.max(2, 5 - p.homingLevel) === 0) {
      const missileCount = 1 + Math.floor(p.homingLevel / 2);
      for (let m = 0; m < missileCount; m++) {
        const side = m % 2 === 0 ? 1 : -1;
        const launchAng = p.angle + side * (0.65 + m * 0.2);
        this.missiles.push({
          x: p.x,
          y: p.y,
          vx: Math.cos(launchAng) * 420,
          vy: Math.sin(launchAng) * 420,
          dmg: p.damage * (1.35 + p.homingLevel * 0.25),
          life: 3.4,
          trail: []
        });
      }
    }

    // Hafif geri tepme hissi
    p.vx -= Math.cos(p.angle) * 22;
    p.vy -= Math.sin(p.angle) * 22;
    this.sound.playShoot(isCrit);
  }

  // ==================== DALGA VE DÜŞMAN SİSTEMİ ====================

  spawnWaveBurst(count) {
    for (let i = 0; i < count; i++) {
      this.spawnEnemy();
    }
  }

  spawnEnemy(forcedType = null, sx = null, sy = null) {
    const preset = DIFFICULTY_PRESETS[this.difficulty];
    const p = this.player;

    // Oyuncudan güvenli mesafede doğma noktası seç
    let x = sx, y = sy;
    if (x === null || y === null) {
      for (let tries = 0; tries < 12; tries++) {
        const angle = Math.random() * Math.PI * 2;
        const dist = 480 + Math.random() * 340;
        const cx = p.x + Math.cos(angle) * dist;
        const cy = p.y + Math.sin(angle) * dist;
        if (cx > 70 && cx < WORLD_W - 70 && cy > 70 && cy < WORLD_H - 70) {
          x = cx; y = cy;
          break;
        }
      }
      if (x === null) {
        x = Math.random() * (WORLD_W - 160) + 80;
        y = Math.random() * (WORLD_H - 160) + 80;
      }
    }

    const scale = (1 + (this.wave - 1) * 0.17) * preset.hpMult;
    let type = forcedType;
    if (!type) {
      const r = Math.random();
      if (this.wave === 1) {
        type = r < 0.72 ? 'chaser' : 'splitter';
      } else if (this.wave === 2) {
        type = r < 0.48 ? 'chaser' : (r < 0.80 ? 'splitter' : 'shooter');
      } else if (this.wave < 5) {
        type = r < 0.36 ? 'chaser' : (r < 0.60 ? 'splitter' : (r < 0.82 ? 'shooter' : 'vortex'));
      } else {
        type = r < 0.28 ? 'chaser' : (r < 0.48 ? 'splitter' : (r < 0.70 ? 'shooter' : (r < 0.86 ? 'vortex' : 'tank')));
      }
    }

    const elite = !forcedType && this.wave >= 3 && Math.random() < 0.08;
    const eMult = elite ? 2.4 : 1.0;

    const defs = {
      chaser:   { radius: 15, hp: 32, speed: 215, color: '#ff2a85', score: 35, xp: 9 },
      splitter: { radius: 20, hp: 48, speed: 155, color: '#00f0ff', score: 50, xp: 13 },
      mini:     { radius: 10, hp: 16, speed: 295, color: '#72efdd', score: 20, xp: 5 },
      shooter:  { radius: 17, hp: 40, speed: 165, color: '#ffd166', score: 60, xp: 15 },
      vortex:   { radius: 22, hp: 72, speed: 105, color: '#9d4edd', score: 80, xp: 20 },
      tank:     { radius: 26, hp: 135, speed: 98, color: '#06d6a0', score: 110, xp: 26 }
    };

    const d = defs[type] || defs.chaser;
    this.enemies.push({
      id: Math.random(),
      type,
      elite,
      isBoss: false,
      x, y,
      vx: 0, vy: 0,
      radius: d.radius * (elite ? 1.28 : 1),
      hp: d.hp * scale * eMult,
      maxHp: d.hp * scale * eMult,
      speed: d.speed * (1 + Math.min(0.45, this.wave * 0.025)),
      color: d.color,
      score: Math.round(d.score * eMult),
      xp: Math.round(d.xp * eMult),
      rot: Math.random() * Math.PI * 2,
      shootTimer: 1.2 + Math.random() * 1.4,
      hitFlash: 0
    });
  }

  spawnBoss() {
    this.bossActive = true;
    const preset = DIFFICULTY_PRESETS[this.difficulty];
    const bossNames = ['HİPER-PRİZMA OMEGA', 'KARADELİK HÜKÜMDARI', 'SİBER-KONSEY TİTAN', 'SONSUZLUK ÇEKİRDEĞİ'];
    const name = bossNames[Math.floor((this.wave / 5 - 1) % bossNames.length)];

    const angle = Math.random() * Math.PI * 2;
    const bx = Math.max(180, Math.min(WORLD_W - 180, this.player.x + Math.cos(angle) * 520));
    const by = Math.max(180, Math.min(WORLD_H - 180, this.player.y + Math.sin(angle) * 520));

    const maxHp = (950 + (this.wave - 5) * 280) * preset.hpMult;

    this.enemies.push({
      id: Math.random(),
      type: 'boss',
      name,
      elite: true,
      isBoss: true,
      x: bx, y: by,
      vx: 0, vy: 0,
      radius: 52,
      hp: maxHp,
      maxHp,
      speed: 120,
      color: '#ff0054',
      score: 1500,
      xp: 160,
      rot: 0,
      phaseTimer: 0,
      shootTimer: 0.4,
      patternAngle: 0,
      hitFlash: 0
    });

    document.getElementById('bossName').textContent = `⚠️ BOSS: ${name}`;
    document.getElementById('bossHud').classList.add('active');
    this.announceBanner(`⚠️ ${name}`, `DALGA ${this.wave} BOSS SAVAŞI!`);
    this.grid.applyForce(bx, by, 300, 520);
    this.spawnShockwave(bx, by, 450, '#ff0054', 5);
    this.cam.shake = 20;
    this.sound.playExplosion(2.0);
  }

  damageEnemy(en, amount, isCrit = false) {
    en.hp -= amount;
    en.hitFlash = 0.09;

    this.spawnText(
      en.x + (Math.random() - 0.5) * 18,
      en.y - en.radius - 6,
      Math.round(amount).toString() + (isCrit ? '!' : ''),
      isCrit ? '#ffd166' : '#ffffff',
      isCrit ? 15 : 11.5
    );

    if (isCrit) {
      this.spawnParticles(en.x, en.y, 7, '#ffd166', 220);
    }

    if (en.hp <= 0 && !en.dead) {
      en.dead = true;
      this.killEnemy(en);
    } else {
      this.sound.playHit();
    }
  }

  killEnemy(en) {
    const p = this.player;
    this.kills++;
    this.totalKillsAllTime++;
    SafeStorage.set('prism_totalkills', this.totalKillsAllTime);

    // Kombo & Skor
    this.combo++;
    this.comboTimer = 3.2;
    const mult = 1 + Math.min(4.0, Math.floor(this.combo / 5) * 0.25);
    this.addScore(en.score * mult);

    // Süpernova Enerji Dolumu
    p.nova = Math.min(100, p.nova + (en.isBoss ? 50 : 2.6) * p.novaChargeRate);

    // Patlama Efektleri & Elastik Izgara Bükülmesi
    const pCount = en.isBoss ? 85 : (en.elite ? 34 : 18);
    this.spawnParticles(en.x, en.y, pCount, en.color, en.isBoss ? 580 : 300);
    this.grid.applyForce(en.x, en.y, en.isBoss ? 320 : 85, en.isBoss ? 560 : 210);
    this.spawnShockwave(en.x, en.y, en.isBoss ? 440 : en.radius * 3.4, en.color, en.isBoss ? 5 : 2);

    if (en.isBoss) {
      this.bossActive = false;
      document.getElementById('bossHud').classList.remove('active');
      this.cam.shake = 28;
      this.hitStop = 0.08;
      this.sound.playExplosion(2.5);
      this.announceBanner('BOSS İMHA EDİLDİ!', '+1500 PUAN • KALKAN VE CAN YENİLENDİ');
      p.hp = Math.min(p.maxHp, p.hp + 45);
      p.shield = p.maxShield;
      // Boss düşen tüm düşman mermilerini temizler
      this.enemyBullets = [];
    } else {
      this.cam.shake = Math.min(14, this.cam.shake + (en.elite ? 7 : 2.4));
      this.sound.playExplosion(en.elite ? 1.3 : 0.65);
    }

    // Bölünen düşman (Splitter) 2 mini parçaya ayrılır
    if (en.type === 'splitter') {
      for (let i = 0; i < 2; i++) {
        const ang = Math.random() * Math.PI * 2;
        this.spawnEnemy('mini', en.x + Math.cos(ang) * 18, en.y + Math.sin(ang) * 18);
      }
    }

    // Prizma Kristalleri (XP) Düşür
    const gemCount = en.isBoss ? 22 : (en.elite ? 5 : 2);
    const valPerGem = en.xp / gemCount;
    for (let g = 0; g < gemCount; g++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = 60 + Math.random() * (en.isBoss ? 260 : 110);
      this.gems.push({
        x: en.x,
        y: en.y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        val: valPerGem,
        hue: en.isBoss ? 48 : 188
      });
    }
  }

  triggerChainLightning(sourceEnemy, jumpsLeft, dmg) {
    let curr = sourceEnemy;
    const visited = new Set([curr.id]);

    for (let j = 0; j < jumpsLeft; j++) {
      let nearest = null;
      let bestDist = 235;
      for (const candidate of this.enemies) {
        if (candidate.dead || visited.has(candidate.id)) continue;
        const d = Math.hypot(candidate.x - curr.x, candidate.y - curr.y);
        if (d < bestDist) {
          bestDist = d;
          nearest = candidate;
        }
      }
      if (!nearest) break;
      visited.add(nearest.id);
      this.lightnings.push({
        x1: curr.x, y1: curr.y,
        x2: nearest.x, y2: nearest.y,
        life: 0.16
      });
      this.damageEnemy(nearest, dmg * 0.65, false);
      curr = nearest;
    }
  }

  hurtPlayer(rawDamage) {
    const p = this.player;
    if (p.invuln > 0 || p.dashActive > 0) return;

    const dmg = rawDamage * DIFFICULTY_PRESETS[this.difficulty].dmgMult;

    // Önce Aegis Enerji Kalkanı absorbe eder
    if (p.shield > 0) {
      p.shield -= 1;
      p.shieldRegenTimer = 9.5;
      p.invuln = 0.65;
      this.shieldFlash = 0.35;
      this.cam.shake = 12;
      this.spawnShockwave(p.x, p.y, 190, '#00f0ff', 3.5);
      this.grid.applyForce(p.x, p.y, 140, 260);
      this.spawnText(p.x, p.y - 26, '🛡️ KALKAN KORUDU!', '#00f0ff', 14);
      this.sound.playExplosion(1.0);
      return;
    }

    p.hp -= dmg;
    p.invuln = 0.55;
    p.shieldRegenTimer = 9.5;
    this.damageFlash = 0.45;
    this.cam.shake = 18;
    this.combo = 0;
    this.sound.playPlayerDamage();
    this.grid.applyForce(p.x, p.y, 160, 280);
    this.spawnParticles(p.x, p.y, 24, '#ff2a85', 340);

    if (p.hp <= 0) {
      p.hp = 0;
      this.gameOver();
    }
  }

  addScore(pts) {
    const mult = DIFFICULTY_PRESETS[this.difficulty].scoreMult;
    this.score += Math.round(pts * mult);
    if (this.score > this.highScore) {
      this.highScore = this.score;
      SafeStorage.set('prism_highscore', this.highScore);
    }
  }

  gainXp(amount) {
    const p = this.player;
    p.xp += amount;
    if (p.xp >= p.xpNext) {
      p.xp -= p.xpNext;
      p.level++;
      p.xpNext = Math.round(p.xpNext * 1.28 + 22);
      p.hp = Math.min(p.maxHp, p.hp + 15);
      this.openUpgradeMenu();
    }
  }

  openUpgradeMenu() {
    const p = this.player;
    const available = UPGRADE_POOL.filter((u) => (p.upgrades[u.id] || 0) < u.maxLvl);
    if (available.length === 0) {
      p.hp = p.maxHp;
      this.addScore(500);
      this.spawnText(p.x, p.y - 30, 'MAKSİMUM SEVİYE! +500 PUAN', '#ffd166', 16);
      return;
    }

    this.state = 'UPGRADE';
    this.sound.playLevelUp();

    // Karıştır ve 3 kart seç
    const shuffled = [...available].sort(() => Math.random() - 0.5);
    this.currentChoices = shuffled.slice(0, 3);

    const container = document.getElementById('cardsRow');
    container.innerHTML = '';

    this.currentChoices.forEach((upg, idx) => {
      const curLvl = p.upgrades[upg.id] || 0;
      const card = document.createElement('div');
      card.className = 'upgrade-card';
      card.style.borderColor = `${upg.color}66`;
      card.innerHTML = `
        <div class="card-rarity" style="background:${upg.color}22; color:${upg.color}; border:1px solid ${upg.color}66">
          ${upg.rarity} • [${idx + 1}]
        </div>
        <div class="card-icon">${upg.icon}</div>
        <div class="card-title">${upg.title}</div>
        <div class="card-desc">${upg.desc}</div>
        <div class="card-lvl">SEVİYE ${curLvl} ➜ ${curLvl + 1}</div>
      `;
      card.addEventListener('click', () => this.selectUpgrade(idx));
      container.appendChild(card);
    });

    document.getElementById('upgradeLvlText').textContent = `SEVİYE ${p.level} ULAŞILDI! BİR SİNERJİ KARTI SEÇ`;
    document.getElementById('upgradeOverlay').classList.remove('hidden');
  }

  selectUpgrade(index) {
    const upg = this.currentChoices[index];
    if (!upg) return;

    const p = this.player;
    p.upgrades[upg.id] = (p.upgrades[upg.id] || 0) + 1;
    upg.apply(p);

    document.getElementById('upgradeOverlay').classList.add('hidden');
    this.state = 'PLAYING';
    this.sound.playNova();
    this.grid.applyForce(p.x, p.y, 170, 360);
    this.spawnShockwave(p.x, p.y, 280, upg.color, 3.5);
    this.spawnText(p.x, p.y - 36, `${upg.icon} ${upg.title} AKTİF!`, upg.color, 16);
  }

  gameOver() {
    this.state = 'GAMEOVER';
    if (this.wave > this.bestWave) {
      this.bestWave = this.wave;
      SafeStorage.set('prism_bestwave', this.bestWave);
    }

    document.getElementById('bossHud').classList.remove('active');
    document.getElementById('touchActions').classList.remove('visible');

    document.getElementById('endScore').textContent = this.score.toLocaleString('tr-TR');
    document.getElementById('endBest').textContent = this.highScore.toLocaleString('tr-TR');
    document.getElementById('endWave').textContent = `${this.wave} (Lv.${this.player.level})`;
    document.getElementById('endKills').textContent = this.kills.toLocaleString('tr-TR');

    document.getElementById('gameOverOverlay').classList.remove('hidden');
  }

  // ==================== PARÇACIK & EFEKT YARDIMCILARI ====================

  spawnParticles(x, y, count, color, maxSpeed = 260) {
    if (this.particles.length > 520) count = Math.min(count, 8);
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = 30 + Math.random() * maxSpeed;
      const life = 0.32 + Math.random() * 0.45;
      this.particles.push({
        x, y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        life,
        maxLife: life,
        size: 1.8 + Math.random() * 3.4,
        color
      });
    }
  }

  spawnShockwave(x, y, maxRadius, color, width = 2.5) {
    this.shockwaves.push({ x, y, radius: 12, maxRadius, color, width, life: 1.0 });
  }

  spawnText(x, y, text, color = '#fff', size = 13) {
    if (this.texts.length > 45) this.texts.shift();
    this.texts.push({ x, y, text, color, size, life: 0.85, maxLife: 0.85 });
  }

  // ==================== ANA GÜNCELLEME DÖNGÜSÜ ====================

  update(rawDt) {
    this.hueShift = (this.hueShift + rawDt * 18) % 360;

    // Arka plan menüsündeyken canlı uzay-zaman dalgaları oluştur
    if (this.state === 'MENU') {
      if (Math.random() < 0.05) {
        const rx = WORLD_W * 0.25 + Math.random() * WORLD_W * 0.5;
        const ry = WORLD_H * 0.25 + Math.random() * WORLD_H * 0.5;
        this.grid.applyForce(rx, ry, 75, 240);
      }
      this.grid.update(rawDt);
      this.sound.intensity = 0.15;
      this.cam.x = WORLD_W / 2 - this.viewW / 2 + Math.sin(performance.now() * 0.0004) * 90;
      this.cam.y = WORLD_H / 2 - this.viewH / 2 + Math.cos(performance.now() * 0.0003) * 60;
      return;
    }

    if (this.state !== 'PLAYING') return;

    // Mikro Hit-Stop (Büyük vuruş hissi)
    if (this.hitStop > 0) {
      this.hitStop -= rawDt;
      return;
    }

    // Bullet-Time (Zaman Bükülmesi) Yönetimi
    if (this.bulletTimeTimer > 0) {
      this.bulletTimeTimer -= rawDt;
      this.timeScale += (0.38 - this.timeScale) * 0.2;
    } else {
      this.timeScale += (1.0 - this.timeScale) * 0.14;
    }

    const dt = rawDt * this.timeScale;
    const pDt = rawDt * (this.bulletTimeTimer > 0 ? 0.72 : 1.0); // Oyuncu zaman bükülmesinde düşmandan daha çevik kalır!
    const p = this.player;

    // Dinamik Müzik Yoğunluğu
    this.sound.intensity = Math.min(1.0, 0.25 + this.enemies.length / 26 + (this.bossActive ? 0.45 : 0));

    // Zamanlayıcılar
    if (p.fireCooldown > 0) p.fireCooldown -= pDt;
    if (p.dashTimer > 0) p.dashTimer = Math.max(0, p.dashTimer - rawDt);
    if (p.dashActive > 0) p.dashActive -= rawDt;
    if (p.invuln > 0) p.invuln -= rawDt;
    if (this.damageFlash > 0) this.damageFlash = Math.max(0, this.damageFlash - rawDt * 1.6);
    if (this.shieldFlash > 0) this.shieldFlash = Math.max(0, this.shieldFlash - rawDt * 1.8);

    // Kalkan Yenilenmesi
    if (p.shield < p.maxShield) {
      p.shieldRegenTimer -= rawDt;
      if (p.shieldRegenTimer <= 0) {
        p.shield = Math.min(p.maxShield, p.shield + 1);
        p.shieldRegenTimer = 9.5;
        this.spawnShockwave(p.x, p.y, 90, '#00bbf9', 2);
        this.spawnText(p.x, p.y - 24, '🛡️ KALKAN YÜKLENDİ', '#00bbf9', 12);
      }
    }

    // Kombo Sayacı
    if (this.comboTimer > 0) {
      this.comboTimer -= rawDt;
      if (this.comboTimer <= 0) this.combo = 0;
    }

    // Dalga İlerlemesi (Her 22 saniyede yeni dalga, her 5 dalgada Boss!)
    if (!this.bossActive) {
      this.waveTimer += dt;
      if (this.waveTimer >= 22) {
        this.waveTimer = 0;
        this.wave++;
        if (this.wave % 5 === 0) {
          this.spawnBoss();
        } else {
          this.announceBanner(`DALGA ${this.wave}`, 'TEHDİT SEVİYESİ YÜKSELDİ!');
          this.spawnWaveBurst(3 + Math.min(8, this.wave));
        }
      }
    }

    // Düşman Doğurma
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      const preset = DIFFICULTY_PRESETS[this.difficulty];
      const maxEnemies = 46;
      if (this.enemies.length < maxEnemies) {
        const batch = this.bossActive ? 1 : (Math.random() < 0.35 ? 2 : 1);
        for (let i = 0; i < batch; i++) this.spawnEnemy();
      }
      const baseInterval = Math.max(0.36, 1.55 - this.wave * 0.085);
      this.spawnTimer = (baseInterval / preset.spawnMult) * (this.bossActive ? 2.1 : 1.0);
    }

    // Oyuncu Hareketi
    let moveX = 0, moveY = 0;
    if (this.keys['KeyW'] || this.keys['ArrowUp']) moveY -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) moveY += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) moveX -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) moveX += 1;

    if (this.touch.moveId !== null) {
      moveX = this.touch.dx;
      moveY = this.touch.dy;
    } else if (moveX !== 0 || moveY !== 0) {
      const len = Math.hypot(moveX, moveY);
      moveX /= len;
      moveY /= len;
    }

    if (p.dashActive > 0) {
      // Dash sırasında hayalet iz bırak ve temas eden düşmanları çarp
      this.afterimages.push({ x: p.x, y: p.y, angle: p.angle, life: 0.24 });
      for (const en of this.enemies) {
        if (Math.hypot(en.x - p.x, en.y - p.y) < en.radius + p.radius + 16) {
          this.damageEnemy(en, p.damage * 0.45, false);
        }
      }
    } else {
      const accel = 11.5;
      p.vx += (moveX * p.speed - p.vx) * Math.min(1, accel * pDt);
      p.vy += (moveY * p.speed - p.vy) * Math.min(1, accel * pDt);
    }

    p.x += p.vx * pDt;
    p.y += p.vy * pDt;

    // Arena Sınırları
    const pad = 28;
    if (p.x < pad) { p.x = pad; p.vx = Math.abs(p.vx) * 0.3; }
    if (p.x > WORLD_W - pad) { p.x = WORLD_W - pad; p.vx = -Math.abs(p.vx) * 0.3; }
    if (p.y < pad) { p.y = pad; p.vy = Math.abs(p.vy) * 0.3; }
    if (p.y > WORLD_H - pad) { p.y = WORLD_H - pad; p.vy = -Math.abs(p.vy) * 0.3; }

    // Oyuncu İzi
    p.trail.push({ x: p.x, y: p.y });
    if (p.trail.length > 14) p.trail.shift();

    // Kamera Takibi (Fare yönüne hafif öngörülü bakış + Ekran sarsıntısı)
    const lookAheadX = (this.mouse.x - this.viewW / 2) * 0.14;
    const lookAheadY = (this.mouse.y - this.viewH / 2) * 0.14;
    const targetCamX = Math.max(-60, Math.min(WORLD_W - this.viewW + 60, p.x - this.viewW / 2 + lookAheadX));
    const targetCamY = Math.max(-60, Math.min(WORLD_H - this.viewH + 60, p.y - this.viewH / 2 + lookAheadY));

    this.cam.x += (targetCamX - this.cam.x) * Math.min(1, 8.5 * rawDt);
    this.cam.y += (targetCamY - this.cam.y) * Math.min(1, 8.5 * rawDt);
    if (this.cam.shake > 0) this.cam.shake = Math.max(0, this.cam.shake - rawDt * 42);

    // Nişan Açısı
    if (this.touch.isTouch) {
      if (this.touch.aimId !== null) {
        p.angle = Math.atan2(this.touch.ay, this.touch.ax);
      } else if (this.enemies.length > 0) {
        // Dokunmatikte sağ analog kullanılmıyorsa en yakın düşmana akıllı nişan
        let closest = null, best = Infinity;
        for (const en of this.enemies) {
          const d = Math.hypot(en.x - p.x, en.y - p.y);
          if (d < best) { best = d; closest = en; }
        }
        if (closest) p.angle = Math.atan2(closest.y - p.y, closest.x - p.x);
      }
    } else {
      this.mouse.worldX = this.mouse.x + this.cam.x;
      this.mouse.worldY = this.mouse.y + this.cam.y;
      p.angle = Math.atan2(this.mouse.worldY - p.y, this.mouse.worldX - p.x);
    }

    // Ateş Etme
    const wantsFire = this.autoFire || this.mouse.down || this.touch.aimId !== null;
    if (wantsFire && p.fireCooldown <= 0) {
      this.fireWeapon();
    }

    // Yörünge Kılıçları (Orbitals) Güncellemesi
    if (p.orbitals > 0) {
      p.orbitalAngle += rawDt * 4.2;
      const orbDist = 56;
      for (let i = 0; i < p.orbitals; i++) {
        const ang = p.orbitalAngle + (Math.PI * 2 / p.orbitals) * i;
        const ox = p.x + Math.cos(ang) * orbDist;
        const oy = p.y + Math.sin(ang) * orbDist;

        // Düşman mermilerini kes!
        for (let b = this.enemyBullets.length - 1; b >= 0; b--) {
          const eb = this.enemyBullets[b];
          if (Math.hypot(eb.x - ox, eb.y - oy) < 16 + eb.radius) {
            this.spawnParticles(eb.x, eb.y, 4, '#4cc9f0', 140);
            this.enemyBullets.splice(b, 1);
          }
        }
        // Düşmanlara temas hasarı
        for (const en of this.enemies) {
          if (Math.hypot(en.x - ox, en.y - oy) < 14 + en.radius && Math.random() < 0.28) {
            this.damageEnemy(en, p.damage * 0.45, false);
          }
        }
      }
    }

    // Oyuncu Tekillik Girdapları (Vortex Dash)
    for (let i = this.vortices.length - 1; i >= 0; i--) {
      const v = this.vortices[i];
      v.life -= dt;
      v.tick -= dt;
      this.grid.applyForce(v.x, v.y, -48 * dt * 60 * 0.12, v.radius);

      for (const en of this.enemies) {
        const dx = v.x - en.x;
        const dy = v.y - en.y;
        const dist = Math.hypot(dx, dy) || 1;
        if (dist < v.radius) {
          const pull = (1 - dist / v.radius) * 420 * dt;
          en.x += (dx / dist) * pull;
          en.y += (dy / dist) * pull;
          if (v.tick <= 0) {
            this.damageEnemy(en, v.dps * 0.25, false);
          }
        }
      }
      if (v.tick <= 0) v.tick = 0.25;
      if (v.life <= 0) this.vortices.splice(i, 1);
    }

    // Oyuncu Mermileri
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.trail.push({ x: b.x, y: b.y });
      if (b.trail.length > 6) b.trail.shift();

      b.x += b.vx * pDt;
      b.y += b.vy * pDt;
      b.life -= pDt;

      // Duvarlardan Sekme (Ricochet)
      let bouncedWall = false;
      if (b.x <= 12 || b.x >= WORLD_W - 12) {
        if (b.bounce > 0) {
          b.vx *= -1;
          b.x = Math.max(13, Math.min(WORLD_W - 13, b.x));
          b.bounce--;
          bouncedWall = true;
        } else { b.life = 0; }
      }
      if (b.y <= 12 || b.y >= WORLD_H - 12) {
        if (b.bounce > 0) {
          b.vy *= -1;
          b.y = Math.max(13, Math.min(WORLD_H - 13, b.y));
          b.bounce--;
          bouncedWall = true;
        } else { b.life = 0; }
      }
      if (bouncedWall) this.spawnParticles(b.x, b.y, 4, '#ff2a85', 140);

      // Düşman Çarpışma Kontrolü
      if (b.life > 0) {
        for (let j = this.enemies.length - 1; j >= 0; j--) {
          const en = this.enemies[j];
          if (en.dead || b.hitIds.has(en.id)) continue;
          const dist = Math.hypot(en.x - b.x, en.y - b.y);
          if (dist < en.radius + b.radius) {
            b.hitIds.add(en.id);
            this.damageEnemy(en, b.dmg, b.isCrit);
            this.grid.applyForce(b.x, b.y, 18, 90);

            if (p.chainLightning > 0 && Math.random() < 0.34 + p.chainLightning * 0.12) {
              this.triggerChainLightning(en, 1 + p.chainLightning, b.dmg);
            }

            if (b.pierce > 0) {
              b.pierce--;
            } else if (b.bounce > 0) {
              b.bounce--;
              // En yakın başka düşmana doğru sek!
              const normalAng = Math.atan2(b.y - en.y, b.x - en.x);
              const spd = Math.hypot(b.vx, b.vy);
              b.vx = Math.cos(normalAng) * spd;
              b.vy = Math.sin(normalAng) * spd;
            } else {
              b.life = 0;
            }
            break;
          }
        }
      }

      if (b.life <= 0) this.bullets.splice(i, 1);
    }

    // Güdümlü Mikro-Füzeler
    for (let i = this.missiles.length - 1; i >= 0; i--) {
      const m = this.missiles[i];
      m.trail.push({ x: m.x, y: m.y });
      if (m.trail.length > 10) m.trail.shift();
      m.life -= pDt;

      // En yakın hedefe yönel
      let target = null, bestD = 750;
      for (const en of this.enemies) {
        const d = Math.hypot(en.x - m.x, en.y - m.y);
        if (d < bestD) { bestD = d; target = en; }
      }
      if (target) {
        const desired = Math.atan2(target.y - m.y, target.x - m.x);
        const curAng = Math.atan2(m.vy, m.vx);
        let diff = desired - curAng;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        const nextAng = curAng + Math.max(-7.5 * pDt, Math.min(7.5 * pDt, diff));
        const spd = 560;
        m.vx = Math.cos(nextAng) * spd;
        m.vy = Math.sin(nextAng) * spd;
      }

      m.x += m.vx * pDt;
      m.y += m.vy * pDt;

      for (const en of this.enemies) {
        if (!en.dead && Math.hypot(en.x - m.x, en.y - m.y) < en.radius + 10) {
          this.damageEnemy(en, m.dmg, true);
          this.spawnShockwave(m.x, m.y, 65, '#ff5400', 2);
          m.life = 0;
          break;
        }
      }

      if (m.life <= 0) this.missiles.splice(i, 1);
    }

    // Düşman Yapay Zekası & Hareketi
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const en = this.enemies[i];
      if (en.dead) {
        this.enemies.splice(i, 1);
        continue;
      }

      if (en.hitFlash > 0) en.hitFlash -= dt;
      en.rot += dt * (en.type === 'vortex' ? 3.5 : 1.6);

      const dx = p.x - en.x;
      const dy = p.y - en.y;
      const dist = Math.hypot(dx, dy) || 1;
      const nx = dx / dist;
      const ny = dy / dist;

      if (en.isBoss) {
        // Boss Davranışı
        en.phaseTimer += dt;
        const phase = Math.floor(en.phaseTimer / 5) % 3;
        en.vx += (nx * en.speed - en.vx) * 2.5 * dt;
        en.vy += (ny * en.speed - en.vy) * 2.5 * dt;

        en.shootTimer -= dt;
        if (en.shootTimer <= 0) {
          if (phase === 0) {
            // Faz 0: Dönen Çift Spiral Mermi Cehennemi
            en.patternAngle += 0.34;
            for (let k = 0; k < 4; k++) {
              const a = en.patternAngle + (Math.PI / 2) * k;
              this.enemyBullets.push({
                x: en.x, y: en.y,
                vx: Math.cos(a) * 320, vy: Math.sin(a) * 320,
                radius: 6.5, dmg: 16, color: '#ff0054'
              });
            }
            en.shootTimer = 0.16;
          } else if (phase === 1) {
            // Faz 1: Oyuncuya Hedefli Yelpaze Atışı
            const baseA = Math.atan2(dy, dx);
            for (let k = -2; k <= 2; k++) {
              const a = baseA + k * 0.16;
              this.enemyBullets.push({
                x: en.x, y: en.y,
                vx: Math.cos(a) * 410, vy: Math.sin(a) * 410,
                radius: 7, dmg: 18, color: '#ffbd00'
              });
            }
            en.shootTimer = 0.68;
          } else {
            // Faz 2: Uzay-Zaman Çekimi + Halka Salvosu
            this.grid.applyForce(en.x, en.y, -90, 420);
            for (let k = 0; k < 12; k++) {
              const a = (Math.PI * 2 / 12) * k + en.rot;
              this.enemyBullets.push({
                x: en.x, y: en.y,
                vx: Math.cos(a) * 270, vy: Math.sin(a) * 270,
                radius: 6, dmg: 15, color: '#c77dff'
              });
            }
            en.shootTimer = 0.85;
          }
        }
        document.getElementById('bossHpFill').style.width = `${Math.max(0, (en.hp / en.maxHp) * 100)}%`;
      } else if (en.type === 'shooter') {
        // Mesafeli Keskin Nişancı: 290px civarında yörünge çizer
        const desiredDist = 290;
        const radial = dist > desiredDist ? 1 : -0.6;
        en.vx += ((nx * radial - ny * 0.75) * en.speed - en.vx) * 4 * dt;
        en.vy += ((ny * radial + nx * 0.75) * en.speed - en.vy) * 4 * dt;

        en.shootTimer -= dt;
        if (en.shootTimer <= 0 && dist < 640) {
          en.shootTimer = 2.1;
          const a = Math.atan2(dy, dx);
          this.enemyBullets.push({
            x: en.x, y: en.y,
            vx: Math.cos(a) * 370, vy: Math.sin(a) * 370,
            radius: 5.5, dmg: 14, color: '#ffd166'
          });
        }
      } else if (en.type === 'vortex') {
        // Karadelik Düşmanı: Uzay-zaman ızgarasını büker ve oyuncuyu çeker!
        en.vx += (nx * en.speed - en.vx) * 3 * dt;
        en.vy += (ny * en.speed - en.vy) * 3 * dt;
        this.grid.applyForce(en.x, en.y, -26 * dt * 60 * 0.1, 230);
        if (dist < 260 && p.dashActive <= 0) {
          const pull = (1 - dist / 260) * 145 * dt;
          p.x -= nx * pull;
          p.y -= ny * pull;
        }
      } else {
        // Standart Takipçi / Splitter / Tank
        en.vx += (nx * en.speed - en.vx) * 4.5 * dt;
        en.vy += (ny * en.speed - en.vy) * 4.5 * dt;

        if (en.type === 'tank') {
          en.shootTimer -= dt;
          if (en.shootTimer <= 0 && dist < 450) {
            en.shootTimer = 2.6;
            for (let k = 0; k < 6; k++) {
              const a = en.rot + (Math.PI / 3) * k;
              this.enemyBullets.push({
                x: en.x, y: en.y,
                vx: Math.cos(a) * 240, vy: Math.sin(a) * 240,
                radius: 6, dmg: 16, color: '#06d6a0'
              });
            }
          }
        }
      }

      // Düşmanların üst üste binmesini engelleyen yumuşak itme (separation)
      for (let j = i - 1; j >= 0 && j > i - 12; j--) {
        const other = this.enemies[j];
        const ox = en.x - other.x;
        const oy = en.y - other.y;
        const minD = en.radius + other.radius + 4;
        const dSq = ox * ox + oy * oy;
        if (dSq > 0.1 && dSq < minD * minD) {
          const d = Math.sqrt(dSq);
          const push = (minD - d) * 0.35;
          en.x += (ox / d) * push;
          en.y += (oy / d) * push;
        }
      }

      en.x = Math.max(en.radius + 14, Math.min(WORLD_W - en.radius - 14, en.x + en.vx * dt));
      en.y = Math.max(en.radius + 14, Math.min(WORLD_H - en.radius - 14, en.y + en.vy * dt));

      // Oyuncu ile Temas Çarpışması
      if (Math.hypot(p.x - en.x, p.y - en.y) < p.radius + en.radius - 3) {
        this.hurtPlayer(en.isBoss ? 28 : 18);
        const knock = Math.atan2(p.y - en.y, p.x - en.x);
        p.vx += Math.cos(knock) * 340;
        p.vy += Math.sin(knock) * 340;
      }
    }

    // Düşman Mermileri
    for (let i = this.enemyBullets.length - 1; i >= 0; i--) {
      const eb = this.enemyBullets[i];
      eb.x += eb.vx * dt;
      eb.y += eb.vy * dt;

      if (eb.x < 0 || eb.x > WORLD_W || eb.y < 0 || eb.y > WORLD_H) {
        this.enemyBullets.splice(i, 1);
        continue;
      }

      if (Math.hypot(eb.x - p.x, eb.y - p.y) < eb.radius + p.radius - 2) {
        this.enemyBullets.splice(i, 1);
        this.hurtPlayer(eb.dmg);
      }
    }

    // Prizma Kristalleri (XP Mıknatıs Fizikleri)
    for (let i = this.gems.length - 1; i >= 0; i--) {
      const g = this.gems[i];
      g.vx *= 0.91;
      g.vy *= 0.91;

      const dx = p.x - g.x;
      const dy = p.y - g.y;
      const dist = Math.hypot(dx, dy) || 1;

      if (dist < p.magnetRadius) {
        const pull = (1 - dist / p.magnetRadius) * 780 + 220;
        g.vx = (dx / dist) * pull;
        g.vy = (dy / dist) * pull;
      }

      g.x += g.vx * rawDt;
      g.y += g.vy * rawDt;

      if (dist < p.radius + 14) {
        this.sound.playPickup(this.combo);
        this.gainXp(g.val);
        this.gems.splice(i, 1);
      }
    }

    // Parçacıklar, Şok Halkaları, Yıldırımlar, Yazılar
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.vx *= 0.94;
      pt.vy *= 0.94;
      pt.life -= rawDt;
      if (pt.life <= 0) this.particles.splice(i, 1);
    }

    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life -= rawDt * 2.1;
      sw.radius += (sw.maxRadius - sw.radius) * Math.min(1, 9 * rawDt);
      if (sw.life <= 0) this.shockwaves.splice(i, 1);
    }

    for (let i = this.lightnings.length - 1; i >= 0; i--) {
      this.lightnings[i].life -= rawDt;
      if (this.lightnings[i].life <= 0) this.lightnings.splice(i, 1);
    }

    for (let i = this.afterimages.length - 1; i >= 0; i--) {
      this.afterimages[i].life -= rawDt;
      if (this.afterimages[i].life <= 0) this.afterimages.splice(i, 1);
    }

    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.y -= 38 * rawDt;
      t.life -= rawDt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }

    this.grid.update(dt);
    this.updateHUD();
  }

  updateHUD() {
    const p = this.player;
    document.getElementById('hpFill').style.width = `${Math.max(0, (p.hp / p.maxHp) * 100)}%`;
    document.getElementById('shieldOverlay').style.width = p.maxShield > 0 ? `${(p.shield / p.maxShield) * 100}%` : '0%';
    document.getElementById('hpText').textContent = `${Math.ceil(p.hp)} / ${p.maxHp}${p.shield > 0 ? ` (+${p.shield}🛡️)` : ''}`;

    document.getElementById('xpFill').style.width = `${Math.min(100, (p.xp / p.xpNext) * 100)}%`;
    document.getElementById('xpText').textContent = `LV.${p.level}`;

    const novaPct = Math.floor(p.nova);
    const novaEl = document.getElementById('novaFill');
    novaEl.style.width = `${novaPct}%`;
    novaEl.classList.toggle('ready', novaPct >= 100);
    document.getElementById('novaText').textContent = novaPct >= 100 ? 'HAZIR! [Q]' : `%${novaPct}`;

    document.getElementById('dashPill').classList.toggle('ready', p.dashTimer <= 0);
    document.getElementById('dashStatus').textContent = p.dashTimer <= 0 ? 'HAZIR' : `${p.dashTimer.toFixed(1)}s`;

    document.getElementById('novaPill').classList.toggle('nova-ready', novaPct >= 100);
    document.getElementById('waveNum').textContent = this.wave;
    document.getElementById('scoreVal').textContent = this.score.toLocaleString('tr-TR');

    const comboEl = document.getElementById('comboBox');
    if (this.combo >= 3) {
      const mult = (1 + Math.min(4.0, Math.floor(this.combo / 5) * 0.25)).toFixed(2);
      comboEl.textContent = `🔥 ${this.combo} KOMBO (x${mult})`;
    } else {
      comboEl.textContent = '';
    }
  }

  // ==================== ÇİZİM MOTORU (RENDERER) ====================

  render() {
    const ctx = this.ctx;
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#05060f';
    ctx.fillRect(0, 0, this.viewW, this.viewH);

    const shakeX = (Math.random() - 0.5) * this.cam.shake;
    const shakeY = (Math.random() - 0.5) * this.cam.shake;
    const cx = this.cam.x + shakeX;
    const cy = this.cam.y + shakeY;

    // 1. Paralaks Uzay Yıldızları
    for (const s of this.stars) {
      const sx = ((s.x - cx * s.depth) % this.viewW + this.viewW) % this.viewW;
      const sy = ((s.y - cy * s.depth) % this.viewH + this.viewH) % this.viewH;
      ctx.fillStyle = `hsla(${s.hue}, 85%, 75%, ${s.alpha})`;
      ctx.fillRect(sx, sy, s.size, s.size);
    }

    ctx.save();
    ctx.translate(-cx, -cy);

    // 2. Elastik Uzay-Zaman Yay Ağı
    this.grid.draw(ctx, cx, cy, this.viewW, this.viewH, this.hueShift);

    // 3. Arena Lazer Duvarları
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.55)';
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 0, WORLD_W, WORLD_H);
    ctx.strokeStyle = 'rgba(255, 42, 133, 0.22)';
    ctx.lineWidth = 10;
    ctx.strokeRect(-4, -4, WORLD_W + 8, WORLD_H + 8);

    if (this.state === 'MENU') {
      ctx.restore();
      return;
    }

    // Parlak Neon Karışım Modu (Additive Glow)
    ctx.globalCompositeOperation = 'lighter';

    // 4. Tekillik Girdapları (Vortex Dash)
    for (const v of this.vortices) {
      const grad = ctx.createRadialGradient(v.x, v.y, 4, v.x, v.y, v.radius);
      grad.addColorStop(0, 'rgba(199, 125, 255, 0.75)');
      grad.addColorStop(0.5, 'rgba(123, 44, 191, 0.28)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(v.x, v.y, v.radius, 0, Math.PI * 2);
      ctx.fill();
    }

    // 5. Şok Dalgaları
    for (const sw of this.shockwaves) {
      ctx.strokeStyle = sw.color;
      ctx.globalAlpha = Math.max(0, sw.life * 0.75);
      ctx.lineWidth = sw.width;
      ctx.beginPath();
      ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // 6. Prizma Kristalleri (XP)
    for (const g of this.gems) {
      ctx.fillStyle = `hsl(${g.hue}, 100%, 65%)`;
      ctx.save();
      ctx.translate(g.x, g.y);
      ctx.rotate(performance.now() * 0.004 + g.x);
      ctx.beginPath();
      ctx.moveTo(0, -6);
      ctx.lineTo(5, 0);
      ctx.lineTo(0, 6);
      ctx.lineTo(-5, 0);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // 7. Dash Hayalet İzleri
    for (const ai of this.afterimages) {
      ctx.save();
      ctx.translate(ai.x, ai.y);
      ctx.rotate(ai.angle);
      ctx.fillStyle = `rgba(0, 240, 255, ${ai.life * 1.8})`;
      ctx.beginPath();
      ctx.moveTo(20, 0);
      ctx.lineTo(-13, -12);
      ctx.lineTo(-7, 0);
      ctx.lineTo(-13, 12);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // 8. Oyuncu Mermileri, Füzeler ve Zincirleme Yıldırımlar
    for (const b of this.bullets) {
      if (b.trail.length > 1) {
        ctx.strokeStyle = b.isCrit ? 'rgba(255, 209, 102, 0.55)' : 'rgba(0, 240, 255, 0.5)';
        ctx.lineWidth = b.radius * 1.2;
        ctx.beginPath();
        ctx.moveTo(b.trail[0].x, b.trail[0].y);
        for (let t = 1; t < b.trail.length; t++) ctx.lineTo(b.trail[t].x, b.trail[t].y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      ctx.fillStyle = b.isCrit ? '#ffd166' : '#ffffff';
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();
    }

    for (const m of this.missiles) {
      if (m.trail.length > 1) {
        ctx.strokeStyle = 'rgba(255, 84, 0, 0.65)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(m.trail[0].x, m.trail[0].y);
        for (let t = 1; t < m.trail.length; t++) ctx.lineTo(m.trail[t].x, m.trail[t].y);
        ctx.stroke();
      }
      ctx.fillStyle = '#ff9e00';
      ctx.beginPath();
      ctx.arc(m.x, m.y, 5.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Yıldırım Arkları
    for (const l of this.lightnings) {
      ctx.strokeStyle = `rgba(180, 120, 255, ${l.life * 6})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(l.x1, l.y1);
      const steps = 5;
      for (let s = 1; s < steps; s++) {
        const t = s / steps;
        const jx = l.x1 + (l.x2 - l.x1) * t + (Math.random() - 0.5) * 24;
        const jy = l.y1 + (l.y2 - l.y1) * t + (Math.random() - 0.5) * 24;
        ctx.lineTo(jx, jy);
      }
      ctx.lineTo(l.x2, l.y2);
      ctx.stroke();
    }

    // 9. Düşman Mermileri
    for (const eb of this.enemyBullets) {
      ctx.fillStyle = eb.color;
      ctx.beginPath();
      ctx.arc(eb.x, eb.y, eb.radius + 2.5, 0, Math.PI * 2);
      ctx.globalAlpha = 0.35;
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(eb.x, eb.y, eb.radius * 0.7, 0, Math.PI * 2);
      ctx.fill();
    }

    // 10. Düşmanlar (Geometrik Neon Vektör Sanat)
    for (const en of this.enemies) {
      ctx.save();
      ctx.translate(en.x, en.y);
      ctx.rotate(en.rot);

      const strokeCol = en.hitFlash > 0 ? '#ffffff' : en.color;
      ctx.strokeStyle = strokeCol;
      ctx.lineWidth = en.isBoss ? 4.5 : (en.elite ? 3.5 : 2.5);

      if (en.elite && !en.isBoss) {
        ctx.strokeStyle = 'rgba(255, 209, 102, 0.55)';
        ctx.beginPath();
        ctx.arc(0, 0, en.radius + 6, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = strokeCol;
      }

      if (en.isBoss) {
        // Çok katmanlı dönen Boss çekirdeği
        for (let layer = 0; layer < 3; layer++) {
          ctx.save();
          ctx.rotate(en.rot * (layer % 2 === 0 ? 1 : -1.4));
          const sides = 6 + layer * 2;
          const rad = en.radius - layer * 13;
          ctx.strokeStyle = layer === 0 ? '#ff0054' : (layer === 1 ? '#ffbd00' : '#00f0ff');
          ctx.beginPath();
          for (let k = 0; k < sides; k++) {
            const a = (Math.PI * 2 / sides) * k;
            const px = Math.cos(a) * rad;
            const py = Math.sin(a) * rad;
            if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.stroke();
          ctx.restore();
        }
      } else {
        const sides = en.type === 'shooter' ? 3 : (en.type === 'chaser' || en.type === 'mini' ? 4 : (en.type === 'tank' ? 5 : 6));
        ctx.fillStyle = `${en.color}30`;
        ctx.beginPath();
        if (en.type === 'vortex') {
          ctx.arc(0, 0, en.radius, 0, Math.PI * 2);
        } else {
          for (let k = 0; k < sides; k++) {
            const a = (Math.PI * 2 / sides) * k;
            const px = Math.cos(a) * en.radius;
            const py = Math.sin(a) * en.radius;
            if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.closePath();
        }
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }

    // 11. Oyuncu Gemisi
    const p = this.player;
    if (p.trail.length > 1) {
      for (let i = 1; i < p.trail.length; i++) {
        const t = i / p.trail.length;
        ctx.strokeStyle = `rgba(0, 240, 255, ${t * 0.45})`;
        ctx.lineWidth = t * 10;
        ctx.beginPath();
        ctx.moveTo(p.trail[i - 1].x, p.trail[i - 1].y);
        ctx.lineTo(p.trail[i].x, p.trail[i].y);
        ctx.stroke();
      }
    }

    // Yörünge Kılıçları Çizimi
    if (p.orbitals > 0) {
      for (let i = 0; i < p.orbitals; i++) {
        const ang = p.orbitalAngle + (Math.PI * 2 / p.orbitals) * i;
        const ox = p.x + Math.cos(ang) * 56;
        const oy = p.y + Math.sin(ang) * 56;
        ctx.fillStyle = '#4cc9f0';
        ctx.beginPath();
        ctx.arc(ox, oy, 7.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.save();
    ctx.translate(p.x, p.y);

    // Aegis Enerji Kalkanı Halkası
    if (p.shield > 0) {
      ctx.strokeStyle = 'rgba(0, 220, 255, 0.55)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, p.radius + 9, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.rotate(p.angle);
    ctx.strokeStyle = p.invuln > 0 && Math.floor(performance.now() / 60) % 2 === 0 ? '#ffd166' : '#00f0ff';
    ctx.fillStyle = 'rgba(0, 240, 255, 0.22)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(21, 0);
    ctx.lineTo(-13, -13);
    ctx.lineTo(-7, 0);
    ctx.lineTo(-13, 13);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Çekirdek Parlaması
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(3, 0, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // 12. Kıvılcım Parçacıkları
    for (const pt of this.particles) {
      const alpha = Math.max(0, pt.life / pt.maxLife);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * alpha, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // 13. Yüzen Hasar ve Bilgi Yazıları
    ctx.globalCompositeOperation = 'source-over';
    ctx.textAlign = 'center';
    for (const t of this.texts) {
      ctx.globalAlpha = Math.min(1, (t.life / t.maxLife) * 1.4);
      ctx.font = `900 ${t.size}px ui-sans-serif, system-ui, sans-serif`;
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;

    ctx.restore();

    // 14. Ekran Kenarı Efektleri (Bullet-Time, Kalkan & Hasar Vinyeti)
    if (this.bulletTimeTimer > 0) {
      ctx.strokeStyle = `rgba(0, 240, 255, ${Math.min(0.45, this.bulletTimeTimer * 0.35)})`;
      ctx.lineWidth = 14;
      ctx.strokeRect(0, 0, this.viewW, this.viewH);
    }
    if (this.damageFlash > 0) {
      ctx.fillStyle = `rgba(255, 20, 80, ${this.damageFlash * 0.42})`;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }
    if (this.shieldFlash > 0) {
      ctx.fillStyle = `rgba(0, 220, 255, ${this.shieldFlash * 0.3})`;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }

    // 15. Sağ Alt Taktiksel Radar (Mini-Map)
    if (this.state === 'PLAYING' || this.state === 'PAUSED') {
      this.drawMinimap(ctx);
    }
  }

  drawMinimap(ctx) {
    const mw = 148;
    const mh = Math.round(mw * (WORLD_H / WORLD_W));
    const mx = this.viewW - mw - 18;
    const my = this.viewH - mh - (this.touch.isTouch ? 105 : 18);

    ctx.save();
    ctx.fillStyle = 'rgba(8, 12, 28, 0.72)';
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(mx, my, mw, mh, 8);
    else ctx.rect(mx, my, mw, mh);
    ctx.fill();
    ctx.stroke();

    const sx = mw / WORLD_W;
    const sy = mh / WORLD_H;

    // Görüş çerçevesi
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
    ctx.lineWidth = 1;
    ctx.strokeRect(
      mx + Math.max(0, this.cam.x * sx),
      my + Math.max(0, this.cam.y * sy),
      Math.min(mw, this.viewW * sx),
      Math.min(mh, this.viewH * sy)
    );

    // Kristaller
    ctx.fillStyle = 'rgba(0, 240, 255, 0.45)';
    for (const g of this.gems) {
      ctx.fillRect(mx + g.x * sx, my + g.y * sy, 1.5, 1.5);
    }

    // Düşmanlar
    for (const en of this.enemies) {
      ctx.fillStyle = en.isBoss ? '#ffd166' : '#ff2a85';
      const r = en.isBoss ? 4 : 2;
      ctx.beginPath();
      ctx.arc(mx + en.x * sx, my + en.y * sy, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Oyuncu
    ctx.fillStyle = '#06d6a0';
    ctx.beginPath();
    ctx.arc(mx + this.player.x * sx, my + this.player.y * sy, 3.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  loop(now) {
    const rawDt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) / 1000));
    this.lastTime = now;

    this.update(rawDt);
    this.render();

    requestAnimationFrame((t) => this.loop(t));
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.game = new Game();
});
