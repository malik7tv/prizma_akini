// Prosedürel Web Audio API Ses ve Synthwave Müzik Motoru
class SoundSystem {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.enabled = true;
    this.musicEnabled = true;
    this.noiseBuffer = null;
    this.beatTimer = null;
    this.step = 0;
    this.intensity = 0; // 0..1 arası aksiyon yoğunluğu

    // C Minör Pentatonik Frekans Tablosu (Müzikal kristal toplama ve efektler için)
    this.pentatonic = [
      261.63, 311.13, 349.23, 392.00, 466.16,
      523.25, 622.25, 698.46, 783.99, 932.33, 1046.50
    ];
  }

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();

    // Dinamik Kompresör: Çok sayıda patlama aynı anda olduğunda cızırtıyı önler
    const comp = this.ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 24;
    comp.ratio.value = 10;
    comp.attack.value = 0.003;
    comp.release.value = 0.2;

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.75;

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = 0.85;

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.28;

    this.sfxGain.connect(comp);
    this.musicGain.connect(comp);
    comp.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);

    // 1 saniyelik Beyaz Gürültü (White Noise) Tamponu
    const sampleRate = this.ctx.sampleRate;
    this.noiseBuffer = this.ctx.createBuffer(1, sampleRate, sampleRate);
    const data = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < sampleRate; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    this.startMusicLoop();
  }

  toggleMute() {
    this.enabled = !this.enabled;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.enabled ? 0.75 : 0, this.ctx.currentTime, 0.05);
    }
    return this.enabled;
  }

  toggleMusic() {
    this.musicEnabled = !this.musicEnabled;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(this.musicEnabled ? 0.28 : 0, this.ctx.currentTime, 0.08);
    }
    return this.musicEnabled;
  }

  startMusicLoop() {
    if (this.beatTimer) clearInterval(this.beatTimer);
    // 125 BPM 16'lık nota adımları (~120ms)
    const bassLine = [
      65.41, 65.41, 130.81, 65.41, 65.41, 65.41, 130.81, 65.41, // C2
      51.91, 51.91, 103.83, 51.91, 58.27, 58.27, 116.54, 77.78  // Ab1 -> Bb1
    ];
    const arpNotes = [523.25, 622.25, 783.99, 932.33, 783.99, 622.25, 523.25, 392.00];

    this.beatTimer = setInterval(() => {
      if (!this.ctx || !this.enabled || !this.musicEnabled || this.ctx.state !== 'running') return;
      const now = this.ctx.currentTime;
      const idx = this.step % 16;

      // Kick Davul (Her 4 adımda bir)
      if (idx % 4 === 0) {
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(145, now);
        osc.frequency.exponentialRampToValueAtTime(36, now + 0.11);
        g.gain.setValueAtTime(0.55, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
        osc.connect(g);
        g.connect(this.musicGain);
        osc.start(now);
        osc.stop(now + 0.14);
      }

      // Hi-hat (Off-beat)
      if (idx % 4 === 2 && this.intensity > 0.15) {
        const src = this.ctx.createBufferSource();
        src.buffer = this.noiseBuffer;
        const hp = this.ctx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 7500;
        const g = this.ctx.createGain();
        g.gain.setValueAtTime(0.14, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.045);
        src.connect(hp);
        hp.connect(g);
        g.connect(this.musicGain);
        src.start(now);
        src.stop(now + 0.05);
      }

      // Synthwave Rolling Bassline
      const freq = bassLine[idx];
      const bOsc = this.ctx.createOscillator();
      const bFilter = this.ctx.createBiquadFilter();
      const bGain = this.ctx.createGain();
      bOsc.type = 'sawtooth';
      bOsc.frequency.setValueAtTime(freq, now);
      bFilter.type = 'lowpass';
      const cutoff = 260 + this.intensity * 750;
      bFilter.frequency.setValueAtTime(cutoff, now);
      bFilter.frequency.exponentialRampToValueAtTime(110, now + 0.11);
      bGain.gain.setValueAtTime(0.26, now);
      bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.115);

      bOsc.connect(bFilter);
      bFilter.connect(bGain);
      bGain.connect(this.musicGain);
      bOsc.start(now);
      bOsc.stop(now + 0.12);

      // Aksiyon yükseldiğinde Arpej katmanı devreye girer
      if (this.intensity > 0.35 && idx % 2 === 1) {
        const aOsc = this.ctx.createOscillator();
        const aGain = this.ctx.createGain();
        aOsc.type = 'triangle';
        aOsc.frequency.setValueAtTime(arpNotes[(this.step >> 1) % arpNotes.length], now);
        aGain.gain.setValueAtTime(0.12 * this.intensity, now);
        aGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        aOsc.connect(aGain);
        aGain.connect(this.musicGain);
        aOsc.start(now);
        aOsc.stop(now + 0.11);
      }

      this.step++;
    }, 120);
  }

  playShoot(isCrit = false) {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = isCrit ? 'sawtooth' : 'triangle';
    const base = isCrit ? 920 : 660 + (Math.random() * 90 - 45);
    osc.frequency.setValueAtTime(base, now);
    osc.frequency.exponentialRampToValueAtTime(170, now + 0.065);
    g.gain.setValueAtTime(isCrit ? 0.20 : 0.13, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.075);
  }

  playHit() {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(290 + Math.random() * 80, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.04);
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.045);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.05);
  }

  playExplosion(power = 1) {
    if (!this.ctx || !this.enabled || !this.noiseBuffer) return;
    const now = this.ctx.currentTime;
    const dur = Math.min(0.18 + power * 0.16, 0.75);

    // Gürültü patlaması
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1100 + power * 400, now);
    filter.frequency.exponentialRampToValueAtTime(80, now + dur);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(Math.min(0.32 * power, 0.65), now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);

    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    src.start(now);
    src.stop(now + dur + 0.02);

    // Alt-bas gövde vuruşu
    const sub = this.ctx.createOscillator();
    const sg = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(135, now);
    sub.frequency.exponentialRampToValueAtTime(28, now + dur * 0.85);
    sg.gain.setValueAtTime(Math.min(0.38 * power, 0.7), now);
    sg.gain.exponentialRampToValueAtTime(0.001, now + dur * 0.85);
    sub.connect(sg);
    sg.connect(this.sfxGain);
    sub.start(now);
    sub.stop(now + dur);
  }

  playPickup(combo = 1) {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const note = this.pentatonic[Math.min(combo % this.pentatonic.length, this.pentatonic.length - 1)];
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(note, now);
    osc.frequency.exponentialRampToValueAtTime(note * 1.25, now + 0.08);
    g.gain.setValueAtTime(0.16, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.095);
  }

  playDash() {
    if (!this.ctx || !this.enabled || !this.noiseBuffer) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 3.5;
    bp.frequency.setValueAtTime(350, now);
    bp.frequency.exponentialRampToValueAtTime(2600, now + 0.16);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.3, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.sfxGain);
    src.start(now);
    src.stop(now + 0.19);
  }

  playNova() {
    if (!this.ctx || !this.enabled) return;
    this.playExplosion(2.2);
    const now = this.ctx.currentTime;
    [261.63, 392.0, 523.25, 783.99].forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f * 0.5, now);
      osc.frequency.exponentialRampToValueAtTime(f * 2, now + 0.55);
      g.gain.setValueAtTime(0.14, now + i * 0.03);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.03);
      osc.stop(now + 0.68);
    });
  }

  playLevelUp() {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const chord = [523.25, 659.25, 783.99, 1046.5];
    chord.forEach((f, idx) => {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      const t = now + idx * 0.065;
      osc.frequency.setValueAtTime(f, t);
      g.gain.setValueAtTime(0.22, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.36);
    });
  }

  playPlayerDamage() {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.linearRampToValueAtTime(55, now + 0.26);
    g.gain.setValueAtTime(0.42, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.3);
  }
}
