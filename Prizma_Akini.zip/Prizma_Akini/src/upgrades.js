// Roguelite Sinerjik Yükseltme Kartları Havuzu
const UPGRADE_POOL = [
  {
    id: 'multishot',
    title: 'Prizma Çatallanması',
    icon: '🔱',
    rarity: 'DESTANSI',
    color: '#ffd166',
    maxLvl: 4,
    desc: 'Silahına +2 açılı foton namlusu ekler. Ateş gücün yelpaze şeklinde yayılır.',
    apply: (p) => { p.projectiles += 2; p.damage *= 0.88; }
  },
  {
    id: 'rapidfire',
    title: 'Hiper-İletken Namlu',
    icon: '⚡',
    rarity: 'NADİR',
    color: '#00f0ff',
    maxLvl: 5,
    desc: 'Atış hızını %26, mermi hızını %18 artırır.',
    apply: (p) => { p.fireRate *= 0.78; p.bulletSpeed *= 1.18; }
  },
  {
    id: 'ricochet',
    title: 'Kuantum Sekmesi',
    icon: '🪃',
    rarity: 'DESTANSI',
    color: '#ff2a85',
    maxLvl: 4,
    desc: 'Mermiler duvarlardan ve düşmanlardan +1 kez seker ve +%15 hasar kazanır.',
    apply: (p) => { p.bounce += 1; p.damage *= 1.15; }
  },
  {
    id: 'pierce',
    title: 'Plazma Delici',
    icon: '☄️',
    rarity: 'NADİR',
    color: '#06d6a0',
    maxLvl: 4,
    desc: 'Mermiler +1 düşmanın içinden delip geçer ve mermi boyutu %20 büyür.',
    apply: (p) => { p.pierce += 1; p.bulletSize *= 1.2; p.damage *= 1.12; }
  },
  {
    id: 'lightning',
    title: 'Tesla Ark Bobini',
    icon: '🌩️',
    rarity: 'EFSANEVİ',
    color: '#9d4edd',
    maxLvl: 4,
    desc: 'Vuruşlar yakındaki düşmanlara yüksek voltajlı zincirleme yıldırım sıçratır.',
    apply: (p) => { p.chainLightning += 1; }
  },
  {
    id: 'orbitals',
    title: 'Yörünge Kılıçları',
    icon: '🪐',
    rarity: 'DESTANSI',
    color: '#4cc9f0',
    maxLvl: 4,
    desc: 'Geminin etrafında dönen +2 plazma küresi ekler; düşman mermilerini keser!',
    apply: (p) => { p.orbitals += 2; }
  },
  {
    id: 'homing',
    title: 'Güdümlü Mikro-Sürü',
    icon: '🚀',
    rarity: 'EFSANEVİ',
    color: '#ff5400',
    maxLvl: 4,
    desc: 'Ateş ederken en yakın hedeflere kilitlenen kavisli mikro-füzeler fırlatır.',
    apply: (p) => { p.homingLevel += 1; }
  },
  {
    id: 'vortex_dash',
    title: 'Tekillik Atılımı',
    icon: '🌀',
    rarity: 'EFSANEVİ',
    color: '#c77dff',
    maxLvl: 3,
    desc: 'Dash yaptığın yerde düşmanları içine vakumlayıp parçalayan karadelik bırakır!',
    apply: (p) => { p.vortexDash += 1; p.dashCooldown *= 0.84; }
  },
  {
    id: 'shield',
    title: 'Aegis Enerji Kalkanı',
    icon: '🛡️',
    rarity: 'NADİR',
    color: '#00bbf9',
    maxLvl: 4,
    desc: 'Kendini yenileyen +1 koruyucu enerji kalkanı ve +25 Maksimum Can sağlar.',
    apply: (p) => {
      p.maxShield += 1;
      p.shield = p.maxShield;
      p.maxHp += 25;
      p.hp = Math.min(p.maxHp, p.hp + 35);
    }
  },
  {
    id: 'crit',
    title: 'Kritik Çekirdek',
    icon: '💎',
    rarity: 'NADİR',
    color: '#ff9e00',
    maxLvl: 5,
    desc: '+%18 Kritik Vuruş şansı ve +%25 Taban Hasar. Kritikler patlayıcı şok yaratır!',
    apply: (p) => { p.critChance += 0.18; p.damage *= 1.25; }
  },
  {
    id: 'magnet',
    title: 'Hiper-Motor & Mıknatıs',
    icon: '🧲',
    rarity: 'YAYGIN',
    color: '#80ffdb',
    maxLvl: 4,
    desc: 'Kristal çekim alanını %65 büyütür, hareket hızını %14 artırır.',
    apply: (p) => { p.magnetRadius *= 1.65; p.speed *= 1.14; }
  },
  {
    id: 'supernova_core',
    title: 'Süpernova Reaktörü',
    icon: '☀️',
    rarity: 'NADİR',
    color: '#ffd166',
    maxLvl: 3,
    desc: 'Süpernova (Q) dolum hızını %45 artırır ve anında +50 Can onarır.',
    apply: (p) => {
      p.novaChargeRate *= 1.45;
      p.hp = Math.min(p.maxHp, p.hp + 50);
      p.nova = Math.min(100, p.nova + 40);
    }
  }
];
