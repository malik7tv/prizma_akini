# 🌌 PRİZMA AKINI (Prism Overdrive)

Tamamen saf HTML5 Canvas, JavaScript ve Web Audio API prosedürel ses motoruyla geliştirilmiş neon roguelite arena shooter oyunu.

## ▶️ Nasıl Çalıştırılır?
Hiçbir kurulum veya internet bağlantısı gerekmez!
1. Klasördeki **`Prizma_Akini.html`** dosyasına çift tıklayın.
2. Varsayılan web tarayıcınızda (Chrome, Edge, Firefox, Safari, Opera) anında tam ekran açılacaktır.

## 🕹️ Kontroller
- **W A S D** veya **Ok Tuşları**: Gemi hareketi *(Mobil/dokunmatik ekranda sol yarıda sürükleyin)*
- **Fare İmleci / Sol Tık**: Nişan alma ve ateş etme *(Oto-Ateş varsayılan açıktır, **F** tuşuyla değiştirilebilir)*
- **Space / Shift / Sağ Tık**: Foton Atılımı (Dash) — Mermilerin yakınından geçerseniz **Bullet-Time** tetikler!
- **Q** veya **E**: Prizma Süpernovası — Tüm düşman mermilerini kristale dönüştürür!
- **1, 2, 3**: Seviye atlama ekranında hızlı kart seçimi
- **M**: Sesi Aç / Kapat
- **P** veya **ESC**: Oyunu Duraklat

## 📂 Kaynak Kod Yapısı (`src/`)
Oyunun kodlarını düzenlemek isterseniz `src/` klasöründeki dosyaları değiştirip `python build.py` komutuyla yeni HTML dosyasını derleyebilirsiniz:
- `src/game.js` — Oyun motoru, fizik, çarpışma, kamera, radar ve düşman yapay zekası
- `src/grid.js` — 2D elastik uzay-zaman yay ağı (Spring-Mass Grid)
- `src/audio.js` — Web Audio API gerçek zamanlı synthwave müzik & ses sentezleyicisi
- `src/upgrades.js` — 12 farklı sinerjik roguelite yükseltme kartı
- `src/style.css` — Arayüz ve HUD tasarımları
